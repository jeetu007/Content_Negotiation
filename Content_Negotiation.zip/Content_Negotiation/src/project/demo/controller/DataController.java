package project.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import project.demo.model.User;
import project.demo.service.UserService;

@RestController
public class DataController {

	@Autowired
	UserService userService;

	@RequestMapping(value = "user/all", headers = "Accept=application/json,application/xml,text/xml,text/plain", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE, MediaType.TEXT_PLAIN_VALUE })
	public ResponseEntity<List<User>> getAllUsers() {
		List<User> allUsers = userService.getAllUser();
		return new ResponseEntity<List<User>>(allUsers, HttpStatus.OK);
	}

	@RequestMapping(value = "user/one/{name}", method = RequestMethod.GET)
	public ResponseEntity<User> getOneUser(@PathVariable("name") String name) {
		User oneUSer = userService.findUser(name);
		return new ResponseEntity<User>(oneUSer, HttpStatus.OK);
	}
}
